namespace CleanArchitecture.Domain.Permissions;


public record PermissionId(int Value);

public record Nombre(string Value);